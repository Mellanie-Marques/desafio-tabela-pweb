import {Usuario} from './usuario';

export const USUARIOS: Array<Usuario> = [
  {
    nome: 'Gustavo',
    idade: 42,
    cpf: '123'
  }
]
